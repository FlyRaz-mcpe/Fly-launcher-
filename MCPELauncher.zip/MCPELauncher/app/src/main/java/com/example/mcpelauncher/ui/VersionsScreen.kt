package com.example.mcpelauncher.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.mcpelauncher.data.VersionDao
import com.example.mcpelauncher.data.VersionEntity
import com.example.mcpelauncher.importer.ApkImporter
import com.example.mcpelauncher.importer.ImportResult
import com.example.mcpelauncher.importer.InstallHelper
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun VersionsScreen(importer: ApkImporter, dao: VersionDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var statusMessage by remember { mutableStateOf<String?>(null) }
    val versions by dao.getAll().collectAsState(initial = emptyList())

    val pickApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            scope.launch {
                when (val result = importer.importFromUri(it)) {
                    is ImportResult.Success -> {
                        dao.insert(result.entity)
                        statusMessage = "Импортировано: ${result.entity.versionName}"
                    }
                    is ImportResult.Error -> {
                        statusMessage = result.message
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Fly Launcher") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                pickApkLauncher.launch(arrayOf("application/vnd.android.package-archive"))
            }) {
                Text("+")
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize()) {
            statusMessage?.let {
                Text(
                    text = it,
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (versions.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Нет импортированных версий.\nНажми + чтобы добавить APK.")
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(versions) { version ->
                        VersionRow(
                            version = version,
                            onPlay = {
                                val installed = InstallHelper.getInstalledVersionCode(context, version.packageName)
                                if (installed != null && installed != version.versionCode) {
                                    // другая версия уже стоит — сначала просим удалить
                                    InstallHelper.uninstallPackage(context, version.packageName)
                                }
                                InstallHelper.installApk(context, File(version.filePath))
                            },
                            onDelete = {
                                scope.launch {
                                    dao.delete(version)
                                    File(version.filePath).delete()
                                    version.iconPath?.let { File(it).delete() }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VersionRow(
    version: VersionEntity,
    onPlay: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val bitmap = remember(version.iconPath) {
            version.iconPath?.let { path ->
                BitmapFactory.decodeFile(path)
            }
        }
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.size(48.dp)
            )
        } else {
            Box(modifier = Modifier.size(48.dp))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(text = "v${version.versionName}", style = MaterialTheme.typography.titleMedium)
            Text(text = version.packageName, style = MaterialTheme.typography.bodySmall)
        }

        TextButton(onClick = onPlay) { Text("Играть") }
        TextButton(onClick = onDelete) { Text("Удалить") }
    }
}
