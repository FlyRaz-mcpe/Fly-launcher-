package com.example.mcpelauncher.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VersionDao {
    @Query("SELECT * FROM versions ORDER BY importDate DESC")
    fun getAll(): Flow<List<VersionEntity>>

    @Insert
    suspend fun insert(version: VersionEntity): Long

    @Delete
    suspend fun delete(version: VersionEntity)
}
