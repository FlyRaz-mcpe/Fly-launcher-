package com.example.mcpelauncher.importer

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object InstallHelper {

    /**
     * Запускает системный установщик для указанного APK-файла.
     * Пользователь увидит стандартный диалог подтверждения установки Android.
     */
    fun installApk(context: Context, apkFile: File) {
        val apkUri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            apkFile
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * Запускает системный диалог удаления текущего установленного пакета.
     * Так как у всех версий MCPE один и тот же packageName, перед установкой
     * новой версии обычно нужно сначала удалить старую.
     */
    fun uninstallPackage(context: Context, packageName: String) {
        val intent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:$packageName")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * Проверка, установлен ли пакет с данным именем (и какая версия).
     * Полезно, чтобы показать в UI "Установлено" / "Не установлено".
     */
    fun getInstalledVersionCode(context: Context, packageName: String): Long? {
        return try {
            val info = context.packageManager.getPackageInfo(packageName, 0)
            info.longVersionCode
        } catch (e: Exception) {
            null
        }
    }
}
