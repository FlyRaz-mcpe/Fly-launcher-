package com.example.mcpelauncher.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "versions")
data class VersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val versionName: String,
    val versionCode: Long,
    val packageName: String,
    val filePath: String,      // путь к APK в приватном хранилище
    val iconPath: String?,     // путь к сохранённой иконке (PNG)
    val importDate: Long = System.currentTimeMillis()
)
