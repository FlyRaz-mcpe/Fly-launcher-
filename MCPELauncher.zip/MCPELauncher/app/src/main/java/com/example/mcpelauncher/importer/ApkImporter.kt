package com.example.mcpelauncher.importer

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import com.example.mcpelauncher.data.VersionEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

sealed class ImportResult {
    data class Success(val entity: VersionEntity) : ImportResult()
    data class Error(val message: String) : ImportResult()
}

class ApkImporter(private val context: Context) {

    private val versionsDir = File(context.filesDir, "versions").apply { mkdirs() }
    private val iconsDir = File(context.filesDir, "icons").apply { mkdirs() }

    suspend fun importFromUri(uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        try {
            // 1. Копируем APK во временный файл — PackageManager умеет читать инфо только с диска
            val tempFile = File(context.cacheDir, "temp_import_${System.currentTimeMillis()}.apk")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext ImportResult.Error("Не удалось открыть файл")

            // 2. Парсим манифест
            val pm = context.packageManager
            val packageInfo = pm.getPackageArchiveInfo(tempFile.absolutePath, PackageManager.GET_META_DATA)
                ?: run {
                    tempFile.delete()
                    return@withContext ImportResult.Error("Файл повреждён или это не APK")
                }

            val packageName = packageInfo.packageName
            val versionName = packageInfo.versionName ?: "unknown"
            val versionCode = packageInfo.longVersionCode

            // 3. Проверка, что это Minecraft (опционально, но полезно для UX)
            if (!packageName.contains("mojang") && !packageName.contains("minecraft")) {
                tempFile.delete()
                return@withContext ImportResult.Error("Похоже, это не Minecraft PE (package: $packageName)")
            }

            // 4. Извлекаем иконку
            packageInfo.applicationInfo?.apply {
                sourceDir = tempFile.absolutePath
                publicSourceDir = tempFile.absolutePath
            }
            val icon: Drawable? = packageInfo.applicationInfo?.loadIcon(pm)
            val iconFile = File(iconsDir, "icon_${versionCode}.png")
            icon?.let { saveDrawableAsPng(it, iconFile) }

            // 5. Перемещаем APK в постоянное хранилище с понятным именем
            val finalFile = File(versionsDir, "mcpe_${versionName}_${versionCode}.apk")
            tempFile.copyTo(finalFile, overwrite = true)
            tempFile.delete()

            ImportResult.Success(
                VersionEntity(
                    versionName = versionName,
                    versionCode = versionCode,
                    packageName = packageName,
                    filePath = finalFile.absolutePath,
                    iconPath = if (icon != null) iconFile.absolutePath else null
                )
            )
        } catch (e: Exception) {
            ImportResult.Error("Ошибка импорта: ${e.message}")
        }
    }

    private fun saveDrawableAsPng(drawable: Drawable, outFile: File) {
        val width = drawable.intrinsicWidth.takeIf { it > 0 } ?: 128
        val height = drawable.intrinsicHeight.takeIf { it > 0 } ?: 128
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        FileOutputStream(outFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
    }
}
